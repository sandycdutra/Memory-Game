Manual:

- Salve seus arquivos na pasta "Simulador".
- Tenha certeza que o "charmap.mif" tamb�m est� na pasta "Simulador".
- Para programar, utilize o "sublime_text.exe" dentro da pasta "Sublime Text 3".
- Com o Sublime Text aberto, pressione F7 para Montar e Simular o c�digo.

F.A.Q:

- Meu F7 n�o compila!
	V� em Tools > Build System , e verifique se a op��o "Assembly ICMC" est� selecionada.

Outros erros, d�vidas ou sugest�es sobre o Sublime Text, entre em contato: carlosasj@hotmail.com.br

---------------------------------------------------------------------------------------------------
English Translation:

Manual:

    Save your files in the "Simulator" folder.
    Make sure the "charmap.mif" is also in the "Simulador" folder.
    To program, use the "sublime_text.exe" inside the "Sublime Text 3" folder.
    With Sublime Text open, press F7 to Assemble and Simulate the code.

F.A.Q:

    My F7 doesn't compile!
    Go to Tools > Build System, and make sure the "Assembly ICMC" option is selected.

For other errors, questions, or suggestions about Sublime Text, please contact: carlosasj@hotmail.com.br